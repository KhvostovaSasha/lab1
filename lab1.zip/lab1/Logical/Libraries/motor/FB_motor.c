
#include <bur/plctypes.h>
#ifdef __cplusplus
	extern "C"
	{
#endif
	#include "motor.h"
#ifdef __cplusplus
	};
#endif
/* TODO: Add your comment here */
void FB_motor(struct FB_motor* inst)
{
	inst->integrator.dt = inst->dt;
	inst ->integrator.in = (inst->u / inst->ke - inst->w) / inst->Tm;
	FB_integrator(&inst->integrator);
	inst->w = inst ->integrator.out;
	inst->phi += inst->w * 6.2832f / 60.0f * inst->dt;
}
