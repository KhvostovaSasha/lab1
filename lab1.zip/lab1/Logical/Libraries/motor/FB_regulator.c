
#include <bur/plctypes.h>
#ifdef __cplusplus
	extern "C"
	{
#endif
	#include "motor.h"
#ifdef __cplusplus
	};
#endif
/* TODO: Add your comment here */
void FB_regulator(struct FB_regulator* inst)
{
	REAL lim = inst->max_abs_value;
	REAL up, u_raw;
	
	inst ->integrator.dt = inst->dt;
	inst->integrator.in = inst->k_i * inst ->e + inst ->iyOld / inst->dt;
	FB_integrator(&inst->integrator);
	
	u_raw = up + inst ->integrator.out;
	inst ->u = u_raw;
	if (inst->u > lim) inst->u = lim;
	if (inst->u < -lim) inst->u = -lim;
	
	inst->iyOld = inst->u - u_raw;
}
