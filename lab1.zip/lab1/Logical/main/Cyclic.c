
#include <bur/plctypes.h>

#ifdef _DEFAULT_INCLUDES
	#include <AsDefault.h>
#endif

void _CYCLIC ProgramCyclic(void)
{
	counter += 0.01f; 
	if (counter >= 60.0f) counter = 0.0f;
	speed = (counter >= 20.0f && counter < 40.0f) ? 60.0f : 0.0f;
	
	if (enable) {
		fb_regulator.e = speed - fb_motor.w;
		FB_regulator(&fb_regulator);
		fb_motor.u = fb_regulator.u;
	} else {
		fb_motor.u = 0.0f;
	}
	FB_motor(&fb_motor);
	
	fb_motor2.u = speed;
	FB_motor(&fb_motor2);
}
