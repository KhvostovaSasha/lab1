
#include <bur/plctypes.h>

#ifdef _DEFAULT_INCLUDES
	#include <AsDefault.h>
#endif

void _INIT ProgramInit(void)
{
	REAL Tzh = 2.0f;
	fb_motor.ke = 1.1f;
	fb_motor.Tm = 0.1f;
	fb_motor.dt = 0.01f;
	
	fb_motor2.ke = 1.1f;
	fb_motor2.Tm = 0.1f;
	fb_motor2.dt = 0.01f;
	
	fb_regulator.k_p = fb_motor.ke * fb_motor.Tm / Tzh;
	fb_regulator.k_i = fb_motor.ke / Tzh;
	fb_regulator.max_abs_value = 100.0f;
	fb_regulator.dt = 0.01f;
	
	enable = 1;
}
