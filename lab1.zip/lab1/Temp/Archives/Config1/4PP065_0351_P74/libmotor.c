void FB_integrator(void) {};
void _FB_integrator(void) {};
void FB_motor(void) {};
void _FB_motor(void) {};
void FB_regulator(void) {};
void _FB_regulator(void) {};
