#ifndef _MAIN_DEFAULT_1222789648
#define _MAIN_DEFAULT_1222789648
#include "../AsDefault.h"
#include <bur/plctypes.h>
#include <bur/plc.h>
#include <typesTYP.h>
#include <variablesVAR.h>
#endif
