/* Automation Studio generated header file */
/* Do not edit ! */

#ifndef _BUR_1789486531_1_
#define _BUR_1789486531_1_

#include <bur/plctypes.h>

/* Constants */
#ifdef _REPLACE_CONST
#else
#endif


/* Variables */
_BUR_LOCAL struct FB_motor fb_motor2;
_BUR_LOCAL float counter;
_BUR_LOCAL plcbit enable;
_BUR_LOCAL float speed;
_BUR_LOCAL struct FB_motor fb_motor;
_BUR_LOCAL struct FB_regulator fb_regulator;





__asm__(".section \".plc\"");

/* Used IEC files */
__asm__(".ascii \"iecfile \\\"Logical/main/Variables.var\\\" scope \\\"local\\\"\\n\"");
__asm__(".ascii \"iecfile \\\"Logical/Libraries/motor/motor.fun\\\" scope \\\"global\\\"\\n\"");

/* Exported library functions and function blocks */

__asm__(".previous");


#endif /* _BUR_1789486531_1_ */

